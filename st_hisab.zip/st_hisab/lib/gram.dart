import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'clientpage.dart';
import 'main.dart';

class GramPage extends StatefulWidget {
  final String type;
  final String typeName;

  const GramPage({super.key, required this.type, required this.typeName});

  @override
  State<GramPage> createState() => _GramPageState();
}

class _GramPageState extends State<GramPage> {
  late Future<List<Client>> clientData;

  @override
  void initState() {
    super.initState();
    clientData = getGramData();
  }

  Future<List<Client>> getGramData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    const String url = 'https://hisab.shopnotech.com/api/get';

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'action': 'getGram',
          'token': prefs.getString('token'),
          'type': widget.type,
        }),
      );

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        return data.map((item) => Client.fromJson(item)).toList();
      } else {
        // Return an empty list or throw an error to be handled later
        return [];
      }
    } catch (error) {
      // Handle the error gracefully, perhaps log it or notify the user
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.typeName} গ্রাম লিস্ট'),
      ),
      body: FutureBuilder<List<Client>>(
        future: clientData,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No data found'));
          } else {
            List<Client> clients = snapshot.data!;
            return GridView.builder(
              padding: const EdgeInsets.all(10),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, // Two items per row
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 0.8, // Adjust height based on content
              ),
              itemCount: clients.length,
              itemBuilder: (context, index) {
                final client = clients[index];
                return InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ClientPage(
                          type: widget.type,
                          typeName: widget.typeName,
                          gram: client.id,
                          gramName: client.name,
                          token: Global.isLoggedIn,
                        ),
                      ),
                    );
                  },
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            backgroundColor: Colors.grey[300],
                            radius: 30,
                            child: const Icon(
                              Icons.area_chart_sharp,
                              color: Colors.black,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            client.name,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}

// Client model
class Client {
  final String id;
  final String name;

  Client({required this.id, required this.name});

  factory Client.fromJson(Map<String, dynamic> json) {
    return Client(
      id: json['id'],
      name: json['name'],
    );
  }
}
