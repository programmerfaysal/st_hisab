// ignore_for_file: prefer_const_constructors

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class ClientJoma extends StatefulWidget {
  final String client;

  const ClientJoma({super.key, required this.client});

  @override
  State<ClientJoma> createState() => _ClientJomaState();
}

class _ClientJomaState extends State<ClientJoma> {
  Map<String, dynamic>? userData;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    getClientData(widget.client); // Fetch user data when the page loads
  }

  // Function to fetch user data using token
  Future<void> getClientData(String client) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String url =
        'https://hisab.shopnotech.com/api/get'; // Your API endpoint for user data

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'action': 'getClientData',
          'token': prefs.getString('token'),
          'client': client,
        }),
      );

      if (response.statusCode == 200) {
        var data = jsonDecode(utf8.decode(response.bodyBytes));
        print(data);
        setState(() {
          userData = data; // Store user data in the state
          isLoading = false;
        });
      } else {
        print('Failed to load user data');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to load user data')),
        );
      }
    } catch (error) {
      print('Error: $error');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Error occurred while fetching user data')),
      );
    }
  }

  // Method to refresh user data
  Future<void> _refreshData() async {
    setState(() {
      isLoading = true; // Show loading indicator while fetching
    });
    await getClientData(widget.client); // Fetch data again
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: const Color.fromARGB(255, 36, 36, 36),
          actions: <Widget>[
            IconButton(
              icon: const Icon(Icons.phone),
              tooltip: 'কল করুন',
              onPressed: () {
                launchUrl(Uri(
                  scheme: 'tel',
                  path: '88${userData!['mobile']}',
                ));
              },
            ),
          ]),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(top: 20),
          child: RefreshIndicator(
            onRefresh: _refreshData, // Call refresh method
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : userData != null
                    ? Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            // User Image
                            const Center(
                              child: ClipOval(
                                child: CircleAvatar(
                                  radius: 50,
                                  backgroundColor: Colors.grey,
                                  child: Icon(Icons.person, size: 50),
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),
                            // User Name
                            Text(
                              '${userData!['name']}',
                              style: const TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromARGB(255, 255, 255, 255)),
                            ),
                            Text(
                              'পিতা/স্বামী:  ${userData!['fname']}',
                              style: const TextStyle(
                                  fontSize: 18,
                                  color: Color.fromARGB(255, 255, 255, 255)),
                            ),
                            const SizedBox(height: 5),
                            // User Email
                            Text(
                              'বিল:  ${userData!['bill']} টাকা',
                              style: const TextStyle(
                                  fontSize: 18,
                                  color: Color.fromARGB(255, 255, 255, 255)),
                            ),

                            Text(
                              'মোবা:  ${userData!['mobile']}',
                              style: const TextStyle(
                                  fontSize: 18,
                                  color: Color.fromARGB(255, 255, 255, 255)),
                            ),
                            Text(
                              'বাকিঁ:  ${userData!['baki']} টাকা',
                              style: const TextStyle(
                                  fontSize: 18,
                                  color: Color.fromARGB(255, 255, 0, 0)),
                            ),
                            userData!['status'] == '1'
                                ? const Text(
                                    'স্টাটাস: চালু',
                                    style: TextStyle(
                                        fontSize: 18,
                                        color: Color.fromARGB(255, 19, 231, 0)),
                                  )
                                : const Text(
                                    'স্টাটাস: বন্ধ',
                                    style: TextStyle(
                                        fontSize: 18,
                                        color: Color.fromARGB(255, 248, 58, 0)),
                                  ),

                            userData!['type'] == '1'
                                ? const Text(
                                    'টাইপ: ডিশ',
                                    style: TextStyle(
                                        fontSize: 18,
                                        color:
                                            Color.fromARGB(255, 255, 255, 255)),
                                  )
                                : const SizedBox(height: 0),

                            userData!['type'] == '2'
                                ? const Text(
                                    'টাইপ: STB',
                                    style: TextStyle(
                                        fontSize: 18,
                                        color:
                                            Color.fromARGB(255, 255, 255, 255)),
                                  )
                                : const SizedBox(height: 0),

                            userData!['type'] == '3'
                                ? const Text(
                                    'টাইপ: WiFi',
                                    style: TextStyle(
                                        fontSize: 18,
                                        color:
                                            Color.fromARGB(255, 255, 255, 255)),
                                  )
                                : const SizedBox(height: 0),

                            const SizedBox(height: 40),
                            Padding(
                              padding: const EdgeInsets.fromLTRB(30, 5, 30, 5),
                              child: TextField(
                                decoration: const InputDecoration(
                                  label: Text('পরিমাণ'),
                                  filled: true,
                                  fillColor: Color.fromARGB(255, 48, 48, 48),
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),
                            isLoading
                                ? const CircularProgressIndicator()
                                : ElevatedButton(
                                    onPressed: () {},
                                    style: ElevatedButton.styleFrom(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 100, vertical: 15),
                                      backgroundColor: const Color.fromARGB(
                                          255, 199, 199, 199),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                    ),
                                    child: const Text(
                                      'জমা করুন',
                                      style: TextStyle(
                                          fontSize: 18, color: Colors.black),
                                    ),
                                  ),
                          ],
                        ),
                      )
                    : const Center(child: Text('Failed to load user data')),
          ),
        ),
      ),
    );
  }
}
