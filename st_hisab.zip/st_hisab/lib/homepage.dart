// ignore_for_file: prefer_const_constructors

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'login.dart';

import 'gram.dart';

class HomePage extends StatefulWidget {
  final String token;

  // Constructor to accept token from login page
  const HomePage({super.key, required this.token});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Map<String, dynamic>? userData;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    getUserData(widget.token); // Fetch user data when the page loads
  }

  // Function to fetch user data using token
  Future<void> getUserData(String token) async {
    String url =
        'https://hisab.shopnotech.com/api/get'; // Your API endpoint for user data

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'action': 'getUserData',
          'token': token,
        }),
      );

      if (response.statusCode == 200) {
        var data = jsonDecode(utf8.decode(response.bodyBytes));
        print(data);
        setState(() {
          userData = data; // Store user data in the state
          isLoading = false;
        });
      } else {
        print('Failed to load user data');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to load user data')),
        );
      }
    } catch (error) {
      print('Error: $error');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Error occurred while fetching user data')),
      );
    }
  }

  // Method to refresh user data
  Future<void> _refreshData() async {
    setState(() {
      isLoading = true; // Show loading indicator while fetching
    });
    await getUserData(widget.token); // Fetch data again
  }

  // Method to handle logout
  Future<void> _logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('token'); // Remove token from shared preferences
    await prefs.setBool(
        'status', false); // Remove token from shared preferences
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(
          builder: (context) => LoginPage()), // Navigate to the login page
      (route) => false, // Remove all previous routes
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.person_2_rounded),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => HomePage(token: userData!['id']),
              ),
            );
          }, // Call logout method when pressed
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout, // Call logout method when pressed
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(top: 20),
          child: SafeArea(
            child: RefreshIndicator(
              onRefresh: _refreshData, // Call refresh method
              child: isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : userData != null
                      ? Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              // User Image
                              Center(
                                child: ClipOval(
                                  child: Image.network(
                                    userData!['image'],
                                    width: 100,
                                    height: 100,
                                    fit: BoxFit.cover,
                                    loadingBuilder: (BuildContext context,
                                        Widget child,
                                        ImageChunkEvent? loadingProgress) {
                                      if (loadingProgress == null) return child;
                                      return Center(
                                        child: CircularProgressIndicator(
                                          value: loadingProgress
                                                      .expectedTotalBytes !=
                                                  null
                                              ? loadingProgress
                                                      .cumulativeBytesLoaded /
                                                  (loadingProgress
                                                          .expectedTotalBytes ??
                                                      1)
                                              : null,
                                        ),
                                      );
                                    },
                                    errorBuilder: (context, error, stackTrace) {
                                      return const CircleAvatar(
                                        radius: 50,
                                        backgroundColor: Colors.grey,
                                        child: Icon(Icons.person, size: 50),
                                      );
                                    },
                                  ),
                                ),
                              ),
                              const SizedBox(height: 20),
                              // User Name
                              Text(
                                '${userData!['name']}',
                                style: const TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Color.fromARGB(255, 255, 255, 255)),
                              ),
                              const SizedBox(height: 5),
                              // User Email
                              Text(
                                'ব্যালেন্স:  ${userData!['balance']} টাকা',
                                style: const TextStyle(
                                    fontSize: 18,
                                    color: Color.fromARGB(255, 255, 255, 255)),
                              ),
                              userData!['role'] == '2'
                                  ? Text(
                                      'বাকিঁ বেতন:  ${userData!['bakiBeton']} টাকা',
                                      style: const TextStyle(
                                          fontSize: 18,
                                          color: Color.fromARGB(
                                              255, 255, 255, 255)),
                                    )
                                  : const SizedBox(height: 0),
                              userData!['role'] == 'admin'
                                  ? Column(
                                      children: [
                                        Text(
                                          'আজকের জমা:  ${userData!['tJoma']} টাকা',
                                          style: const TextStyle(
                                              fontSize: 18,
                                              color: Color.fromARGB(
                                                  255, 255, 255, 255)),
                                        ),
                                        Text(
                                          'আজকের খরচ:  ${userData!['tBei']} টাকা',
                                          style: const TextStyle(
                                              fontSize: 18,
                                              color: Color.fromARGB(
                                                  255, 255, 255, 255)),
                                        ),
                                      ],
                                    )
                                  : const SizedBox(height: 0),
                              const SizedBox(height: 30),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Expanded(
                                    child: Card(
                                      color: Colors.black,
                                      child: InkWell(
                                        onTap: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => GramPage(
                                                  type: '1', typeName: 'ডিশ'),
                                            ),
                                          );
                                        },
                                        child: const Padding(
                                          padding: EdgeInsets.all(25),
                                          child: Center(
                                            child: Column(
                                              children: [
                                                Icon(Icons.tv_outlined,
                                                    color: Colors.white),
                                                Text("ডিশ গ্রাহক",
                                                    style: TextStyle(
                                                        color: Colors.white)),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Card(
                                      color: Colors.black,
                                      child: InkWell(
                                        onTap: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => GramPage(
                                                  type: '2', typeName: 'STB'),
                                            ),
                                          );
                                        },
                                        child: const Padding(
                                          padding: EdgeInsets.all(25),
                                          child: Center(
                                            child: Column(
                                              children: [
                                                Icon(Icons.smart_screen_rounded,
                                                    color: Colors.white),
                                                Text("STB গ্রাহক",
                                                    style: TextStyle(
                                                        color: Colors.white)),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Expanded(
                                    child: Card(
                                      color: Colors.black,
                                      child: InkWell(
                                        onTap: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => GramPage(
                                                  type: '3', typeName: 'WiFi'),
                                            ),
                                          );
                                        },
                                        child: const Padding(
                                          padding: EdgeInsets.all(25),
                                          child: Center(
                                            child: Column(
                                              children: [
                                                Icon(Icons.wifi,
                                                    color: Colors.white),
                                                Text("WiFi গ্রাহক",
                                                    style: TextStyle(
                                                        color: Colors.white)),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const Expanded(
                                    child: Card(
                                      color: Colors.black,
                                      child: InkWell(
                                        child: Padding(
                                          padding: EdgeInsets.all(25),
                                          child: Center(
                                            child: Column(
                                              children: [
                                                Icon(Icons.account_box,
                                                    color: Colors.white),
                                                Text("প্রোফাইল",
                                                    style: TextStyle(
                                                        color: Colors.white)),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 30),
                              userData!['role'] == 'admin'
                                  ? const Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceAround,
                                      children: [
                                        Expanded(
                                          child: Card(
                                            color: Colors.black,
                                            child: Padding(
                                              padding: EdgeInsets.all(25),
                                              child: Center(
                                                child: Column(
                                                  children: [
                                                    Icon(Icons.person_outlined,
                                                        color: Colors.white),
                                                    Text("কর্মচারী",
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white)),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          child: Card(
                                            color: Colors.black,
                                            child: Padding(
                                              padding: EdgeInsets.all(25),
                                              child: Center(
                                                child: Column(
                                                  children: [
                                                    Icon(
                                                        Icons
                                                            .analytics_outlined,
                                                        color: Colors.white),
                                                    Text("মোট হিসাব",
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white)),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    )
                                  : const SizedBox(height: 0),
                            ],
                          ),
                        )
                      : const Center(child: Text('Failed to load user data')),
            ),
          ),
        ),
      ),
    );
  }
}
