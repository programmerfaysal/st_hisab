import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'login.dart';
import 'homepage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized(); // Ensure binding is initialized
  SharedPreferences prefs = await SharedPreferences.getInstance();

  // Get the login status and token from SharedPreferences
  String? token = prefs.getString('token'); // Nullable token
  bool isLoggedInStatus = prefs.getBool('status') ?? false;

  runApp(MyApp(token: token, isLoggedInStatus: isLoggedInStatus));
}

class MyApp extends StatelessWidget {
  final String? token;
  final bool isLoggedInStatus;

  const MyApp(
      {super.key,
      this.token,
      required this.isLoggedInStatus}); // Nullable token

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark(),
      home: isLoggedInStatus && token != null && token!.isNotEmpty
          ? HomePage(token: token!)
          : LoginPage(),
    );
  }
}

class Global {
  static String gramName = ''; // Login status variable
  static String typeName = ''; // Login status variable
  static String isLoggedIn = ''; // Login status variable
  static bool isLoggedInStatus = false; // Login status variable
}
