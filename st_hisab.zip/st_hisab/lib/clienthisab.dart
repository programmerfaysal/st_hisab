import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart'; // Import intl for date formatting

class Clienthisab extends StatefulWidget {
  final String client;

  const Clienthisab({
    super.key,
    required this.client,
  });
  @override
  State<Clienthisab> createState() => _ClienthisabState();
}

class _ClienthisabState extends State<Clienthisab> {
  late Future<List<Client>> clientData; // Store the future client data
  List<Client> clients = []; // Store the list of clients

  @override
  void initState() {
    super.initState();
    clientData = getClientData(widget.client); // Initialize Future
  }

  Future<List<Client>> getClientData(String client) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String url = 'https://hisab.shopnotech.com/api/get'; // Your API endpoint

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'action': 'getClientHisab',
          'token': prefs.getString('token'),
          'client': widget.client,
        }),
      );

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        clients = data
            .map((item) => Client.fromJson(item))
            .toList(); // Store the list of clients
        return clients;
      } else {
        throw Exception('Failed to load client data');
      }
    } catch (error) {
      return [];
    }
  }

  Future<void> refreshClients() async {
    // Re-fetch the client data on refresh
    setState(() {
      clientData = getClientData(widget.client);
    });
  }

  // Method to format the date as "May 23, 2024 9:13 AM"
  String formatDate(String dateString) {
    try {
      final DateTime parsedDate = DateTime.parse(dateString);
      return DateFormat('MMM d, yyyy h:mm a')
          .format(parsedDate); // Format date and time
    } catch (e) {
      return dateString; // Return original string if parsing fails
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('জমার তালিকা'),
      ),
      body: Column(
        children: [
          Expanded(
            child: FutureBuilder<List<Client>>(
                future: clientData, // Use the Future variable
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    // Show loading indicator while waiting for the data
                    return const Center(child: CircularProgressIndicator());
                  } else if (snapshot.hasError) {
                    // Show error if the API call failed
                    return Center(child: Text('Error: ${snapshot.error}'));
                  } else if (!snapshot.hasData || clients.isEmpty) {
                    // Show a message if the list is empty
                    return const Center(child: Text('No clients found'));
                  } else {
                    // If the data is successfully fetched, display the list
                    return RefreshIndicator(
                      onRefresh: refreshClients,
                      child: ConstrainedBox(
                        constraints: BoxConstraints.expand(
                            width: MediaQuery.of(context).size.width),
                        child: SingleChildScrollView(
                          child: DataTable(
                            columnSpacing: 30,
                            columns: const [
                              DataColumn(label: Text('তারিখ')),
                              DataColumn(label: Text('জের')),
                              DataColumn(label: Text('জমা')),
                              DataColumn(label: Text('বাকিঁ')),
                            ],
                            rows: List.generate(clients.length, (index) {
                              final client = clients[index];
                              final date = client.date;
                              final jer = client.jer;
                              final joma = client.joma;
                              final baki = client.baki;

                              return DataRow(cells: [
                                DataCell(
                                  Container(
                                    child: Text(formatDate(client.date)),
                                  ),
                                ),
                                DataCell(Container(child: Text(jer))),
                                DataCell(Container(child: Text(joma))),
                                DataCell(Container(child: Text(baki))),
                              ]);
                            }),
                          ),
                        ),
                      ),
                    );
                  }
                }),
          )
        ],
      ),
    );
  }
}

// Client model
class Client {
  final String date;
  final String id;
  final String jer;
  final String joma;
  final String baki;
  final String user;

  Client({
    required this.id,
    required this.date,
    required this.jer,
    required this.joma,
    required this.baki,
    required this.user,
  });

  // Factory constructor to create a Client object from JSON
  factory Client.fromJson(Map<String, dynamic> json) {
    return Client(
      id: json['id'] ?? '',
      date: json['date'] ?? '',
      joma: json['joma'] ?? '',
      jer: json['jer'] ?? '',
      baki: json['baki'] ?? '',
      user: json['user'] ?? '',
    );
  }
}
