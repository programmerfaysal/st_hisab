import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'client.dart';
import 'main.dart';

class ClientPage extends StatefulWidget {
  final String type;
  final String typeName;
  final String gram;
  final String gramName;
  final String token;

  const ClientPage(
      {super.key,
      required this.type,
      required this.typeName,
      required this.token,
      required this.gram,
      required this.gramName});

  @override
  State<ClientPage> createState() => _ClientPageState();
}

class _ClientPageState extends State<ClientPage> {
  late Future<List<Client>> clientData; // Store the future client data
  List<Client> clients = []; // Store the list of clients
  List<Client> filteredClients = []; // Store the filtered clients for search
  TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    clientData = getClientData(
        widget.token, widget.type, widget.gram); // Initialize Future
    searchController.addListener(() {
      filterClients();
    });
  }

  Future<List<Client>> getClientData(
      String token, String gram, String type) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String url = 'https://hisab.shopnotech.com/api/get'; // Your API endpoint

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'action': 'getClient',
          'token': prefs.getString('token'),
          'gram': widget.gram,
          'type': widget.type,
        }),
      );

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        // Convert the data to List<Client> using a map function
        clients = data
            .map((item) => Client.fromJson(item))
            .toList(); // Store the original list
        filteredClients = clients; // Initialize the filtered list
        return clients;
      } else {
        throw Exception('Failed to load client data');
      }
    } catch (error) {
      throw Exception('Error: $error');
    }
  }

  void filterClients() {
    String query = searchController.text.toLowerCase();
    setState(() {
      filteredClients = clients.where((client) {
        return client.name.toLowerCase().contains(query) ||
            client.fname.toLowerCase().contains(query) ||
            client.phone.toLowerCase().contains(query);
      }).toList();
    });
  }

  Future<void> refreshClients() async {
    // Re-fetch the client data on refresh
    setState(() {
      clientData = getClientData(widget.token, widget.gram, widget.type);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.gramName} ${widget.typeName} গ্রাহক লিস্ট'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: searchController,
              decoration: const InputDecoration(
                labelText: 'গ্রাহক সার্চ করুন...',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Client>>(
              future: clientData, // Use the Future variable
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  // Show loading indicator while waiting for the data
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  // Show error if the API call failed
                  return Center(child: Text('Error: ${snapshot.error}'));
                } else if (!snapshot.hasData || filteredClients.isEmpty) {
                  // Show a message if the list is empty
                  return const Center(child: Text('No clients found'));
                } else {
                  // If the data is successfully fetched, display the list
                  return RefreshIndicator(
                    onRefresh: refreshClients,
                    child: ListView.builder(
                      itemCount: filteredClients.length,
                      itemBuilder: (context, index) {
                        final client = filteredClients[index];
                        return Card(
                          margin: const EdgeInsets.symmetric(
                              vertical: 5, horizontal: 10),
                          child: ListTile(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ClientView(
                                      client: client.id,
                                      token: Global.isLoggedIn),
                                ),
                              );
                            },
                            tileColor: client.status == '1'
                                ? Colors.black
                                : const Color.fromARGB(255, 179, 12, 0),
                            contentPadding: const EdgeInsets.all(10),
                            leading: CircleAvatar(
                              backgroundColor: client.billMonth ==
                                      '${DateTime.now().month}/${DateTime.now().year}'
                                  ? const Color.fromARGB(255, 0, 167, 50)
                                  : const Color.fromARGB(255, 59, 59, 59),
                              child: Text(client.no),
                            ),
                            title: Text(client.name,
                                style: const TextStyle(fontSize: 20)),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(client.fname),
                                Text(client.phone),
                              ],
                            ),
                            trailing: CircleAvatar(
                              backgroundColor: Colors.red,
                              child: Text(client.baki),
                            ),
                            isThreeLine: true,
                          ),
                        );
                      },
                    ),
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}

// Client model
class Client {
  final String name;
  final String id;
  final String fname;
  final String no;
  final String baki;
  final String phone;
  final String billMonth;
  final String status;

  Client(
      {required this.id,
      required this.no,
      required this.name,
      required this.fname,
      required this.baki,
      required this.phone,
      required this.billMonth,
      required this.status});

  // Factory constructor to create a Client object from JSON
  factory Client.fromJson(Map<String, dynamic> json) {
    return Client(
      id: json['id'] ?? '',
      no: json['no'] ?? '',
      name: json['name'] ?? '',
      fname: json['fname'] ?? '',
      baki: json['baki'] ?? '',
      phone: json['mobile'] ?? '',
      status: json['status'] ?? '',
      billMonth: json['month'] ?? '',
    );
  }
}
