import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart'; // Import shared_preferences
import 'homepage.dart';
import 'main.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool isLoading = false;
  bool rememberMe = false; // Variable to track "Remember Me" state

  @override
  void initState() {
    super.initState();
    _loadCredentials(); // Load saved credentials on init
  }

  Future<void> _loadCredentials() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? savedEmail = prefs.getString('email'); // Retrieve saved email
    String? savedPassword =
        prefs.getString('password'); // Retrieve saved password

    if (savedEmail != null) {
      emailController.text = savedEmail; // Set email field
      passwordController.text =
          savedPassword ?? ''; // Set password field if it exists
      rememberMe = true; // Set remember me to true
    }
  }

  Future<void> _saveCredentials(String token) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('status', true); // Save login status
    await prefs.setString('token', token);

    if (rememberMe) {
      await prefs.setString('email', emailController.text); // Save email
      await prefs.setString(
          'password', passwordController.text); // Save password
    } else {
      await prefs.remove('email'); // Remove saved email
      await prefs.remove('password'); // Remove saved password
    }
  }

  Future<void> login(String email, String password) async {
    setState(() {
      isLoading = true;
    });

    // API endpoint URL
    String url = 'https://hisab.shopnotech.com/api/get';
    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'action': 'login',
          'user': email,
          'password': password,
        }),
      );

      if (response.statusCode == 200) {
        // API call successful, handle the response
        var data = jsonDecode(utf8.decode(response.bodyBytes));

        // Check if the token exists in the response
        if (data['token'] != null) {
          String token = data['token'];
          Global.isLoggedIn = token;
          await _saveCredentials(
              token); // Save credentials if "Remember Me" is checked
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => HomePage(token: Global.isLoggedIn),
            ),
          );
        } else {
          _showError('Login failed: Invalid credentials');
        }
      } else {
        _showError('Login failed: ${response.reasonPhrase}');
      }
    } catch (error) {
      _showError('Error occurred while logging in: $error');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 32, 56, 68),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const Icon(
                  Icons.lock_outline,
                  size: 100,
                  color: Color.fromARGB(255, 199, 199, 199),
                ),
                const SizedBox(height: 20),
                const Text(
                  'Login',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 199, 199, 199),
                  ),
                ),
                const SizedBox(height: 40),
                TextField(
                  controller: emailController,
                  decoration: const InputDecoration(
                    label: Text('Username'),
                    prefixIcon: Icon(Icons.email,
                        color: Color.fromARGB(255, 90, 90, 90)),
                    filled: true,
                    fillColor: Color.fromARGB(255, 48, 48, 48),
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    label: Text('Password'),
                    prefixIcon: Icon(Icons.lock,
                        color: Color.fromARGB(255, 90, 90, 90)),
                    filled: true,
                    fillColor: Color.fromARGB(255, 48, 48, 48),
                  ),
                ),
                const SizedBox(height: 30),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Checkbox(
                      value: rememberMe,
                      onChanged: (bool? value) {
                        setState(() {
                          rememberMe =
                              value ?? false; // Update remember me state
                        });
                      },
                    ),
                    const Text(
                      'Remember Me',
                      style: TextStyle(color: Colors.white),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                isLoading
                    ? const CircularProgressIndicator()
                    : ElevatedButton(
                        onPressed: () {
                          if (!isLoading) {
                            String email = emailController.text;
                            String password = passwordController.text;
                            if (email.isNotEmpty && password.isNotEmpty) {
                              login(email, password);
                            } else {
                              _showError('Please fill all fields');
                            }
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 100, vertical: 15),
                          backgroundColor:
                              const Color.fromARGB(255, 199, 199, 199),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        child: const Text(
                          'Login',
                          style: TextStyle(fontSize: 18, color: Colors.black),
                        ),
                      ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
