import 'package:flutter/material.dart';

class loader extends StatelessWidget {
  const loader({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Image.asset('logo.png', width: 100),
      ),
    );
  }
}
