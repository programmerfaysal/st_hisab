package com.example.st_hisab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
